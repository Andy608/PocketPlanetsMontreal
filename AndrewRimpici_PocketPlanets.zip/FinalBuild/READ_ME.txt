Andrew Rimpici
Neil Devine
Advanced Seminar
12/13/18

Pocket Planets V2.0

30 Second Trailer: https://www.youtube.com/watch?v=HBwOjzQg_Ho

Pocket Planets is a relaxing sandbox game that allows you to explore the wonders of gravity, 
smash things together, and create interesting solar systems. Each experience is different everytime you play.


CONTROLS
================================================================================================================

Pocket Planet was originally designed with touch input in mind, but mouse input is also available.

All mouse input is the same as it would be with touch input.

- Right clicking is the same as touching the screen. 
- The scroll wheel is the same as zooming with your fingers. 
- Right clicking while dragging the mouse is the same as dragging your finger.

Mouse Input Extras:
- Holding down the middle mouse button while dragging allows for camera panning, 
  instead of having to click on the Freeroam Camera button manually.


================================================================================================================

Enjoy!